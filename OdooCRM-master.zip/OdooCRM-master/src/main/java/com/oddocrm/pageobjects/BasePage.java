package com.oddocrm.pageobjects;

public class BasePage 
{
	public String crm="//div[text()='CRM']";
	public String emailID="//span[text()=''{0}'']";
	public String configuration="//a[contains(text(),'Configuration')]";
	public String sales="//ul[@role='menu']//a[contains(text(),'Sales')]";
	public String meunuLink="//img[@alt='Avatar']/parent::a";
	public String logoutLink="//a[text()='Log out']";
}
