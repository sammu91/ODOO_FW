package com.oddocrm.pageobjects;

public class ConfigurationPage 
{
	public String salesTeams="//span[text()='Sales Teams']";
	
}
