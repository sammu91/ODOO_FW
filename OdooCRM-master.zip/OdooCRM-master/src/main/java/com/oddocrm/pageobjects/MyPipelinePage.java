package com.oddocrm.pageobjects;

public class MyPipelinePage 
{
	public String pipeline="//span[text()='My Pipeline']";
	public String createBtn="//button[contains(text(),'Create')]";
	public String oppNameTxtBx="//input[@name='name']";
	public String customerTxtBx="//div[@name='partner_id']//input";
	public String customer="//a[text()=''{0}'']";
	public String addBtn="(//button[text()='Add'])[1]";
}
