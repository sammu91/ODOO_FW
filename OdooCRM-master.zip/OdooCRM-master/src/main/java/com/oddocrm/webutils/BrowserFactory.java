package com.oddocrm.webutils;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.remote.RemoteWebDriver;

import com.oddocrm.generic.GenericLib;

public class BrowserFactory 
{
	public static WebDriver launch(String browserName, String headless)
	{
		WebDriver driver=null;
		
		if (System.getProperty("platformName").equalsIgnoreCase("Windows")) 
		{
			if (browserName.equalsIgnoreCase("chrome")) 
			{
				ChromeCapabilities cap=new ChromeCapabilities();
				System.setProperty("webdriver.chrome.driver", GenericLib.dirPath+"\\exefiles\\chromedriver.exe");
				driver=new ChromeDriver(cap.getChromeCapabilities(headless));
			}
			else if(browserName.equalsIgnoreCase("firefox"))
			{
				FirefoxCapabilties cap=new FirefoxCapabilties();
				System.setProperty("webdriver.gecko.driver", GenericLib.dirPath+"\\exefiles\\geckodriver.exe");
				driver=new FirefoxDriver(cap.getFirefoxCapabilities(headless));
			}
		}
		else if(System.getProperty("platformName").equalsIgnoreCase("Linux"))
		{
			
		}
		else if(System.getProperty("platformName").equalsIgnoreCase("Mac"))
		{
			
		}
		return driver;
	}
	
	public static WebDriver remoteLaunch(String browserName, String headless)
	{
		WebDriver driver=null;
		
		if (System.getProperty("platformName").equalsIgnoreCase("Windows")) 
		{
			if (browserName.equalsIgnoreCase("chrome")) 
			{
				ChromeCapabilities cap=new ChromeCapabilities();
				System.setProperty("webdriver.chrome.driver", GenericLib.dirPath+"\\exefiles\\chromedriver.exe");
				driver=new RemoteWebDriver(cap.getChromeCapabilities(headless));
			}
			else if(browserName.equalsIgnoreCase("firefox"))
			{
				FirefoxCapabilties cap=new FirefoxCapabilties();
				System.setProperty("webdriver.gecko.driver", GenericLib.dirPath+"\\exefiles\\geckodriver.exe");
				driver=new RemoteWebDriver(cap.getFirefoxCapabilities(headless));
			}
		}
		else if(System.getProperty("platformName").equalsIgnoreCase("Linux"))
		{
			
		}
		else if(System.getProperty("platformName").equalsIgnoreCase("Mac"))
		{
			
		}
		return driver;
	}
}
