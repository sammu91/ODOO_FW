package com.odocrm.features;

import com.oddocrm.steps.CommonSteps;
import com.oddocrm.steps.LoginSteps;

import io.qameta.allure.Epic;
import io.qameta.allure.Feature;

public class LoginFeature 
{
	LoginSteps ls;
	CommonSteps cs;
	
	public LoginFeature()
	{
		ls=new LoginSteps();
		cs=new CommonSteps();
	}
	@Epic("Login epic")
	@Feature("performing and validating valid login {username} and {password}")
	public void validLogin(String username, String password)
	{
		ls.login(username, password);
		ls.verifyValidLogin(username);
		cs.logout();
	}
	
	@Epic("Login epic")
	@Feature("performing and validating Invalid login {username} and {password}")
	public void InvalidLogin(String username, String password)
	{
		ls.login(username, password);
		ls.verifyInValidLogin();
	}
	
	
}
