package com.oddocrm.scripts;

import org.testng.annotations.Test;

import com.oddocrm.generic.ExcelUtilities;
import com.oddocrm.generic.GenericLib;

public class SalesTest extends BaseAbstractTest
{
	@Test
	public void createCustomer()
	{
		ExcelUtilities eu=new ExcelUtilities(GenericLib.dirPath+"\\testdata\\Odoodata.xlsx");
		String[] data = eu.readData("createNewCustomer_ID", "Sheet1");
		lf.validLogin(data[1], data[2]);
		sf.createNewCustomer(data[3], data[4], data[5], data[6], data[7], data[8], data[9]);	
	}
	
	@Test(dependsOnMethods= {"createCustomer"})
	public void createOpportunity()
	{
		ExcelUtilities eu=new ExcelUtilities(GenericLib.dirPath+"\\testdata\\Odoodata.xlsx");
		String[] data = eu.readData("createOpportunity_ID", "Sheet1");
		sf.createNewOpportunity(data[3], data[4]);
	}
}
